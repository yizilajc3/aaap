# 🍼 Gestion des Actes de Naissance

Une application web moderne et sécurisée pour la gestion complète des demandes d'actes de naissance, développée avec Flask et SQLite.

## ✨ Fonctionnalités

- **🏥 Interface Hôpital** : Soumission des demandes d'actes de naissance
- **👔 Interface Secrétaire** : Vérification et validation des demandes
- **🏛️ Interface Bourgmestre** : Validation finale et génération des actes
- **🔐 Authentification sécurisée** avec gestion des rôles
- **📊 Tableau de bord** avec statistiques en temps réel
- **🎨 Design moderne** avec animations fluides et responsive
- **📱 Interface mobile** optimisée

## 🚀 Installation

### Prérequis
- Python 3.8 ou supérieur
- pip (gestionnaire de paquets Python)

### Étapes d'installation

1. **Cloner le repository**
```bash
git clone <url-du-repo>
cd ActeNaissance
```

2. **Créer un environnement virtuel**
```bash
python -m venv venv
source venv/bin/activate  # Sur Linux/Mac
# ou
venv\Scripts\activate     # Sur Windows
```

3. **Installer les dépendances**
```bash
pip install -r requirements.txt
```

4. **Lancer l'application**
```bash
python app.py
```

5. **Accéder à l'application**
Ouvrez votre navigateur et allez sur `http://localhost:5000`

## 👥 Comptes de démonstration

L'application est livrée avec des comptes de test préconfigurés :

| Rôle | Email | Mot de passe |
|------|-------|--------------|
| 🏥 Hôpital | `jean.dupont@hopital.be` | `password123` |
| 👔 Secrétaire | `marie.martin@commune.be` | `password123` |
| 🏛️ Bourgmestre | `pierre.bernard@commune.be` | `password123` |

## 🏗️ Architecture

```
ActeNaissance/
├── app.py                 # Application Flask principale
├── requirements.txt       # Dépendances Python
├── README.md             # Documentation
├── templates/            # Templates HTML
│   ├── base.html        # Template de base
│   ├── index.html       # Page d'accueil
│   ├── login.html       # Page de connexion
│   ├── dashboard.html   # Tableau de bord
│   └── nouvelle_demande.html # Formulaire de demande
├── static/              # Fichiers statiques
│   ├── css/
│   │   └── style.css   # Styles CSS personnalisés
│   ├── js/
│   │   └── main.js     # JavaScript principal
│   └── images/         # Images et icônes
└── cahier_charges_actes_naissance.md # Spécifications
```

## 🔧 Configuration

### Variables d'environnement

Créez un fichier `.env` à la racine du projet :

```env
FLASK_SECRET_KEY=votre_cle_secrete_ici
FLASK_ENV=development
DATABASE_URL=sqlite:///actes_naissance.db
```

### Base de données

L'application utilise SQLite par défaut. La base de données sera créée automatiquement au premier lancement.

## 📱 Utilisation

### 1. Page d'accueil
- Présentation du système
- Navigation vers la connexion
- Informations sur les fonctionnalités

### 2. Connexion
- Authentification par email/mot de passe
- Gestion des rôles automatique

### 3. Tableau de bord
- **Hôpital** : Voir ses demandes, créer de nouvelles demandes
- **Secrétaire** : Vérifier les demandes en attente
- **Bourgmestre** : Valider les demandes vérifiées

### 4. Gestion des demandes
- Création de demandes complètes
- Suivi du statut en temps réel
- Validation par étapes

## 🎨 Design et UX

- **Design moderne** avec Bootstrap 5
- **Animations fluides** avec CSS3 et JavaScript
- **Icônes Font Awesome** pour une meilleure lisibilité
- **Responsive design** pour tous les appareils
- **Thème cohérent** avec la charte graphique

## 🔒 Sécurité

- **Authentification sécurisée** avec Flask-Login
- **Gestion des rôles** et permissions
- **Validation des formulaires** côté client et serveur
- **Protection CSRF** intégrée
- **Chiffrement des mots de passe** avec Werkzeug

## 🚀 Déploiement

### Développement local
```bash
python app.py
```

### Production
```bash
export FLASK_ENV=production
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

## 🧪 Tests

Pour exécuter les tests (à implémenter) :
```bash
python -m pytest tests/
```

## 📊 Base de données

### Modèles principaux

- **User** : Utilisateurs avec rôles (hôpital, secrétaire, bourgmestre)
- **Demande** : Demandes d'actes de naissance
- **ActeNaissance** : Actes validés et générés

### Schéma de base

```sql
-- Table des utilisateurs
CREATE TABLE user (
    id INTEGER PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    mot_de_passe VARCHAR(200) NOT NULL,
    role VARCHAR(20) NOT NULL,
    date_creation DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Table des demandes
CREATE TABLE demande (
    id INTEGER PRIMARY KEY,
    id_hopital INTEGER NOT NULL,
    id_secretaire INTEGER,
    id_bourgmestre INTEGER,
    status VARCHAR(20) DEFAULT 'en_attente',
    date_creation DATETIME DEFAULT CURRENT_TIMESTAMP,
    date_validation DATETIME,
    nom_enfant VARCHAR(100) NOT NULL,
    prenom_enfant VARCHAR(100) NOT NULL,
    date_naissance DATE NOT NULL,
    nom_parent VARCHAR(100) NOT NULL,
    prenom_parent VARCHAR(100) NOT NULL
);
```

## 🔄 Workflow

1. **🏥 Hôpital** soumet une demande
2. **👔 Secrétaire** vérifie et valide la demande
3. **🏛️ Bourgmestre** valide finalement et génère l'acte
4. **📄 Acte de naissance** est créé et enregistré

## 🛠️ Technologies utilisées

- **Backend** : Flask (Python)
- **Base de données** : SQLite
- **Frontend** : HTML5, CSS3, JavaScript
- **Framework CSS** : Bootstrap 5
- **Icônes** : Font Awesome 6
- **Authentification** : Flask-Login
- **ORM** : SQLAlchemy

## 📝 Licence

Ce projet est développé pour des fins éducatives et de démonstration.

## 🤝 Contribution

Les contributions sont les bienvenues ! N'hésitez pas à :

1. Fork le projet
2. Créer une branche pour votre fonctionnalité
3. Commiter vos changements
4. Pousser vers la branche
5. Ouvrir une Pull Request

## 📞 Support

Pour toute question ou problème :

- Créez une issue sur GitHub
- Contactez l'équipe de développement

## 🔮 Roadmap

- [ ] Génération PDF des actes
- [ ] Notifications par email
- [ ] API REST
- [ ] Tests automatisés
- [ ] Interface d'administration
- [ ] Export des données
- [ ] Sauvegarde automatique
- [ ] Logs d'audit

---

**Développé avec ❤️ pour la gestion moderne des actes de naissance** 