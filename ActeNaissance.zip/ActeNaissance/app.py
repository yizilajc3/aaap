from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
import os
from datetime import datetime
from flask import jsonify
from flask import send_file
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.graphics.barcode import qr
from reportlab.graphics.shapes import Drawing
from reportlab.graphics import renderPDF

app = Flask(__name__)
app.config['SECRET_KEY'] = 'votre_cle_secrete_ici'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///actes_naissance.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Modèles de base de données
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(100), nullable=False)
    prenom = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    mot_de_passe = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # admin, hopital, particulier, secretaire, bourgmestre
    statut = db.Column(db.String(20), default='en_attente_validation')  # en_attente_validation, valide, rejete, desactive
    hopital_id = db.Column(db.Integer, db.ForeignKey('hopital.id'), nullable=True)  # Pour les particuliers
    date_creation = db.Column(db.DateTime, default=datetime.utcnow)
    date_validation = db.Column(db.DateTime, nullable=True)
    valide_par = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)  # Admin/Bourgmestre qui a validé

class Hopital(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(200), nullable=False)
    adresse = db.Column(db.String(300), nullable=False)
    telephone = db.Column(db.String(20), nullable=False)
    email_contact = db.Column(db.String(120), nullable=False)
    statut = db.Column(db.String(20), default='en_attente_validation')
    date_creation = db.Column(db.DateTime, default=datetime.utcnow)
    date_validation = db.Column(db.DateTime, nullable=True)
    valide_par = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)

class Demande(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    id_hopital = db.Column(db.Integer, db.ForeignKey('hopital.id'), nullable=False)
    id_particulier = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    id_secretaire = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    id_bourgmestre = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    status = db.Column(db.String(20), default='en_attente')
    date_creation = db.Column(db.DateTime, default=datetime.utcnow)
    date_validation = db.Column(db.DateTime, nullable=True)
    
    # Informations sur l'enfant
    nom_enfant = db.Column(db.String(100), nullable=False)
    prenom_enfant = db.Column(db.String(100), nullable=False)
    date_naissance = db.Column(db.Date, nullable=False)
    nom_parent = db.Column(db.String(100), nullable=False)
    prenom_parent = db.Column(db.String(100), nullable=False)

class ActeNaissance(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    demande_id = db.Column(db.Integer, db.ForeignKey('demande.id'), nullable=False)
    pdf_path = db.Column(db.String(200), nullable=True)
    date_generation = db.Column(db.DateTime, default=datetime.utcnow)

# --- Nouveaux modèles ---
class Commune(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(100), unique=True, nullable=False)
    bourgmestre_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    date_attribution = db.Column(db.DateTime, nullable=True)

class BourgmestreCandidature(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    commune_id = db.Column(db.Integer, db.ForeignKey('commune.id'), nullable=False)
    statut = db.Column(db.String(20), default='en_attente')  # en_attente, valide, rejete
    date_creation = db.Column(db.DateTime, default=datetime.utcnow)

class Historique(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    date_evenement = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    role = db.Column(db.String(20), nullable=True)
    action = db.Column(db.String(100), nullable=False)
    entite = db.Column(db.String(50), nullable=True)
    entite_id = db.Column(db.Integer, nullable=True)
    details = db.Column(db.Text, nullable=True)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Utilitaires Historique
def log_event(action: str, entite: str = None, entite_id: int = None, details: str = None, user: User = None):
    try:
        evt = Historique(
            user_id=(user.id if user else (current_user.id if hasattr(current_user, 'id') else None)),
            role=(user.role if user else (current_user.role if hasattr(current_user, 'role') else None)),
            action=action,
            entite=entite,
            entite_id=entite_id,
            details=details
        )
        db.session.add(evt)
        db.session.commit()
    except Exception:
        db.session.rollback()

# Utilitaires PDF
def _ensure_actes_dir() -> str:
    base_dir = os.path.join(app.root_path, 'instance', 'actes')
    os.makedirs(base_dir, exist_ok=True)
    return base_dir

def _acte_file_path(acte_id: int) -> str:
    directory = _ensure_actes_dir()
    return os.path.join(directory, f'acte_{acte_id}.pdf')

def generate_acte_pdf(demande: "Demande", acte: "ActeNaissance", bourgmestre: "User") -> str:
    """Génère un PDF officiel de l'acte de naissance et retourne le chemin absolu du fichier."""
    file_path = _acte_file_path(acte.id)
    c = canvas.Canvas(file_path, pagesize=A4)
    width, height = A4

    margin_x = 20 * mm
    margin_y = 20 * mm

    # Filigrane diagonal discret
    c.saveState()
    c.setFont('Helvetica-Bold', 40)
    c.setFillColor(colors.Color(0.85, 0.85, 0.85))
    c.translate(width/2, height/2)
    c.rotate(45)
    c.drawCentredString(0, 0, 'ACTE DE NAISSANCE')
    c.restoreState()

    # Bandeau d'en-tête
    c.setFillColor(colors.HexColor('#0d6efd'))
    c.rect(0, height - 42 * mm, width, 42 * mm, fill=1, stroke=0)

    # Emblème (cercle) à gauche
    c.setFillColor(colors.white)
    c.circle(20 * mm, height - 21 * mm, 10 * mm, fill=1, stroke=0)
    c.setFillColor(colors.HexColor('#0d6efd'))
    c.setLineWidth(3)
    c.circle(20 * mm, height - 21 * mm, 8.5 * mm, fill=0, stroke=1)

    # Titres d'en-tête
    c.setFillColor(colors.white)
    c.setFont('Helvetica-Bold', 16)
    c.drawString(margin_x + 15 * mm, height - 18 * mm, 'République Démocratique du Congo')
    c.setFont('Helvetica', 11)
    c.drawString(margin_x + 15 * mm, height - 25 * mm, 'Ville de Kinshasa - Administration Communale')

    # Numéro de référence
    ref_num = f"AN-{demande.id:06d}-{acte.id:04d}"
    c.setFont('Helvetica-Bold', 12)
    c.drawRightString(width - margin_x, height - 18 * mm, f"Réf: {ref_num}")

    # Titre principal
    c.setFillColor(colors.black)
    c.setFont('Helvetica-Bold', 22)
    c.drawCentredString(width / 2, height - 55 * mm, 'ACTE DE NAISSANCE')

    # Cadre global
    box_top = height - 60 * mm
    box_left = margin_x
    box_width = width - 2 * margin_x
    box_height = 140 * mm
    c.setLineWidth(1)
    c.setStrokeColor(colors.HexColor('#6c757d'))
    c.roundRect(box_left, box_top - box_height, box_width, box_height, 5 * mm, stroke=1, fill=0)

    # Fonction helper section
    def section_header(y, title):
        c.setFillColor(colors.HexColor('#f2f4f7'))
        c.rect(box_left, y - 10 * mm, box_width, 10 * mm, fill=1, stroke=0)
        c.setFillColor(colors.HexColor('#0d6efd'))
        c.setFont('Helvetica-Bold', 12)
        c.drawString(box_left + 5 * mm, y - 7 * mm, title)
        c.setFillColor(colors.black)

    def labeled_value(x, y, label, value, w=65 * mm):
        c.setFont('Helvetica-Bold', 11)
        c.drawString(x, y, label)
        c.setFont('Helvetica', 11)
        # zone
        c.setFillColor(colors.HexColor('#fafafa'))
        c.rect(x, y - 6 * mm, w, 7 * mm, fill=1, stroke=0)
        c.setFillColor(colors.black)
        c.drawString(x + 2 * mm, y - 5 * mm, value)

    y = box_top - 5 * mm

    # Section Acte
    section_header(y, 'Informations de l\'acte')
    y -= 15 * mm
    labeled_value(box_left + 5 * mm, y, 'Numéro d\'acte', str(acte.id), 55 * mm)
    labeled_value(box_left + 70 * mm, y, 'Référence', ref_num, 70 * mm)
    labeled_value(box_left + 150 * mm, y, 'Date de génération', acte.date_generation.strftime('%d/%m/%Y %H:%M'), 50 * mm)

    # Section Enfant
    y -= 15 * mm
    section_header(y + 10 * mm, 'Informations sur l\'enfant')
    labeled_value(box_left + 5 * mm, y - 5 * mm, 'Nom', demande.nom_enfant)
    labeled_value(box_left + 80 * mm, y - 5 * mm, 'Prénom', demande.prenom_enfant)
    labeled_value(box_left + 155 * mm, y - 5 * mm, 'Date de naissance', demande.date_naissance.strftime('%d/%m/%Y'), 45 * mm)

    # Section Parent
    y -= 20 * mm
    section_header(y + 10 * mm, 'Informations du parent déclarant')
    labeled_value(box_left + 5 * mm, y - 5 * mm, 'Nom', demande.nom_parent)
    labeled_value(box_left + 80 * mm, y - 5 * mm, 'Prénom', demande.prenom_parent)

    # Section Établissement
    y -= 20 * mm
    section_header(y + 10 * mm, 'Établissement et validation')
    hopital = Hopital.query.get(demande.id_hopital)
    hopital_nom = hopital.nom if hopital else '—'
    labeled_value(box_left + 5 * mm, y - 5 * mm, 'Hôpital de naissance', hopital_nom, 130 * mm)
    statut_label = {'en_attente': 'En attente', 'verifiee': 'Vérifiée', 'validee': 'Validée'}.get(demande.status, demande.status.title())
    labeled_value(box_left + 140 * mm, y - 5 * mm, 'Statut', statut_label, 60 * mm)
    y -= 15 * mm
    labeled_value(box_left + 5 * mm, y - 5 * mm, 'Validée le', demande.date_validation.strftime('%d/%m/%Y %H:%M') if demande.date_validation else '—', 70 * mm)
    labeled_value(box_left + 80 * mm, y - 5 * mm, 'Autorité', f"{bourgmestre.prenom} {bourgmestre.nom} - Bourgmestre", 120 * mm)

    # Zone signatures
    sig_y = box_top - box_height + 30 * mm
    c.setFont('Helvetica', 11)
    c.drawString(box_left, sig_y + 20 * mm, 'Signature du Bourgmestre:')
    c.line(box_left, sig_y + 18 * mm, box_left + 70 * mm, sig_y + 18 * mm)
    c.drawString(box_left + 90 * mm, sig_y + 20 * mm, 'Signature du Secrétaire:')
    c.line(box_left + 90 * mm, sig_y + 18 * mm, box_left + 160 * mm, sig_y + 18 * mm)

    # Tampon visuel "OFFICIEL"
    c.saveState()
    c.setStrokeColor(colors.HexColor('#dc3545'))
    c.setFillColor(colors.white)
    c.setLineWidth(2)
    cx = width - 45 * mm
    cy = sig_y + 15 * mm
    c.circle(cx, cy, 14 * mm, stroke=1, fill=1)
    c.setFillColor(colors.HexColor('#dc3545'))
    c.setFont('Helvetica-Bold', 10)
    c.drawCentredString(cx, cy + 2 * mm, 'OFFICIEL')
    c.setFont('Helvetica', 8)
    c.drawCentredString(cx, cy - 4 * mm, 'COMMUNE')
    c.restoreState()

    # QR code de vérification (contenu minimal)
    qr_content = f"Acte:{acte.id};Demande:{demande.id};Ref:{ref_num};Date:{(demande.date_validation or datetime.utcnow()).strftime('%Y-%m-%d %H:%M')}"
    q = qr.QrCodeWidget(qr_content)
    b = q.getBounds()
    w_qr = b[2] - b[0]
    h_qr = b[3] - b[1]
    d = Drawing(30 * mm, 30 * mm)
    scale_x = (30 * mm) / w_qr
    scale_y = (30 * mm) / h_qr
    d.add(q, name='qr')
    d.scale(scale_x, scale_y)
    renderPDF.draw(d, c, box_left, box_top - box_height + 10 * mm)
    c.setFont('Helvetica', 8)
    c.setFillColor(colors.HexColor('#6c757d'))
    c.drawString(box_left + 32 * mm, box_top - box_height + 22 * mm, 'Vérification: QR interne')

    # Pied de page
    c.setFillColor(colors.HexColor('#6c757d'))
    c.setFont('Helvetica', 9)
    c.drawCentredString(width/2, 12 * mm, 'Document officiel généré par le Système de Gestion des Actes de Naissance — Ville de Kinshasa')
    c.setFont('Helvetica', 8)
    c.drawRightString(width - margin_x, 12 * mm, datetime.utcnow().strftime('Généré le %d/%m/%Y %H:%M UTC'))

    c.showPage()
    c.save()
    return file_path

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/inscription', methods=['GET', 'POST'])
def inscription():
    if request.method == 'POST':
        type_inscription = request.form['type_inscription']
        
        if type_inscription == 'hopital':
            # Inscription d'un hôpital
            hopital = Hopital(
                nom=request.form['nom_hopital'],
                adresse=request.form['adresse_hopital'],
                telephone=request.form['telephone_hopital'],
                email_contact=request.form['email_hopital']
            )
            db.session.add(hopital)
            db.session.flush()  # Pour récupérer l'ID
            
            # Créer l'utilisateur hôpital
            user = User(
                nom=request.form['nom_contact'],
                prenom=request.form['prenom_contact'],
                email=request.form['email_contact'],
                mot_de_passe=generate_password_hash(request.form['mot_de_passe']),
                role='hopital',
                hopital_id=hopital.id
            )
            db.session.add(user)
            db.session.commit()
            
            flash('Demande d\'inscription de l\'hôpital soumise avec succès ! Elle sera validée par l\'administrateur.', 'success')
            return redirect(url_for('index'))
            
        elif type_inscription == 'particulier':
            # Inscription d'un particulier
            hopital_nom = request.form['hopital_naissance']
            
            # Vérifier si l'hôpital existe et est validé
            hopital = Hopital.query.filter_by(nom=hopital_nom, statut='valide').first()
            
            if not hopital:
                flash('L\'hôpital spécifié n\'existe pas ou n\'est pas encore validé dans le système.', 'error')
                return redirect(url_for('inscription'))
            
            # Créer l'utilisateur particulier
            user = User(
                nom=request.form['nom_particulier'],
                prenom=request.form['prenom_enfant'],
                email=request.form['email_particulier'],
                mot_de_passe=generate_password_hash(request.form['mot_de_passe']),
                role='particulier',
                hopital_id=hopital.id
            )
            db.session.add(user)
            db.session.commit()
            
            flash('Inscription réussie ! Vous pouvez maintenant vous connecter pour soumettre votre demande.', 'success')
            return redirect(url_for('login'))
        
        elif type_inscription == 'bourgmestre':
            # Inscription d'un bourgmestre
            commune_id = int(request.form.get('commune_id', '0') or '0')
            commune = Commune.query.get(commune_id)
            if not commune:
                flash('Commune invalide.', 'error')
                return redirect(url_for('inscription'))
            if commune.bourgmestre_id:
                flash('Cette commune est déjà attribuée à un bourgmestre.', 'error')
                return redirect(url_for('inscription'))
            # Empêcher deux candidatures en attente pour la même commune
            candidature_existante = BourgmestreCandidature.query.filter_by(commune_id=commune_id, statut='en_attente').first()
            if candidature_existante:
                flash('Une candidature est déjà en attente pour cette commune.', 'error')
                return redirect(url_for('inscription'))

            user = User(
                nom=request.form['nom_bourgmestre'],
                prenom=request.form['prenom_bourgmestre'],
                email=request.form['email_bourgmestre'],
                mot_de_passe=generate_password_hash(request.form['mot_de_passe_bourgmestre']),
                role='bourgmestre',
                statut='en_attente_validation'
            )
            db.session.add(user)
            db.session.flush()

            candidature = BourgmestreCandidature(user_id=user.id, commune_id=commune_id)
            db.session.add(candidature)
            db.session.commit()

            flash('Candidature de bourgmestre soumise. Elle sera validée par l\'administrateur.', 'success')
            return redirect(url_for('login'))
    
    # GET -> charger les communes et indisponibilités
    communes = Commune.query.order_by(Commune.nom.asc()).all()
    communes_indisponibles = {c.id for c in communes if c.bourgmestre_id}
    # Communes avec candidature en attente
    pending = BourgmestreCandidature.query.filter_by(statut='en_attente').all()
    communes_pending = {c.commune_id for c in pending}
    return render_template('inscription.html', communes=communes, communes_indisponibles=communes_indisponibles, communes_pending=communes_pending)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        mot_de_passe = request.form['mot_de_passe']
        user = User.query.filter_by(email=email).first()
        
        if user and check_password_hash(user.mot_de_passe, mot_de_passe):
            # Exiger statut 'valide' pour tous sauf admin
            if user.role != 'admin' and user.statut != 'valide':
                flash("Votre compte n'est pas actif (validation requise ou désactivé)", 'warning')
                return redirect(url_for('login'))
            login_user(user)
            flash(f'Bienvenue {user.prenom} {user.nom} !', 'success')
            log_event('connexion', entite='user', entite_id=user.id, details='Connexion réussie', user=user)
            return redirect(url_for('dashboard'))
        else:
            flash('Email ou mot de passe incorrect', 'error')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Vous avez été déconnecté', 'info')
    return redirect(url_for('index'))

# --- Route rétablie: nouvelle demande (hôpital/particulier) ---
@app.route('/nouvelle_demande', methods=['GET', 'POST'])
@login_required
def nouvelle_demande():
    if current_user.role not in ['hopital', 'particulier']:
        flash('Accès non autorisé', 'error')
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        nouvelle_demande = Demande(
            id_hopital=current_user.hopital_id,
            id_particulier=current_user.id if current_user.role == 'particulier' else None,
            nom_enfant=request.form['nom_enfant'],
            prenom_enfant=request.form['prenom_enfant'],
            date_naissance=datetime.strptime(request.form['date_naissance'], '%Y-%m-%d').date(),
            nom_parent=request.form['nom_parent'],
            prenom_parent=request.form['prenom_parent']
        )
        db.session.add(nouvelle_demande)
        db.session.commit()
        log_event('creation_demande', entite='demande', entite_id=nouvelle_demande.id, details='Nouvelle demande créée')
        flash('Demande créée avec succès', 'success')
        return redirect(url_for('dashboard'))
    
    return render_template('nouvelle_demande.html')

# --- Gestion des secrétaires (Bourgmestre) ---
@app.route('/bourgmestre/secretaires')
@login_required
def lister_secretaires():
    if current_user.role != 'bourgmestre':
        flash('Accès non autorisé', 'error')
        return redirect(url_for('dashboard'))
    secretaires = User.query.filter_by(role='secretaire', valide_par=current_user.id).order_by(User.date_creation.desc()).all()
    return render_template('gestion_secretaires.html', secretaires=secretaires)

@app.route('/api/bourgmestre/secretaires/<int:secretaire_id>/activer', methods=['POST'])
@login_required
def api_activer_secretaire(secretaire_id):
    if current_user.role != 'bourgmestre':
        return jsonify({'success': False, 'message': "Accès non autorisé"}), 403
    sec = User.query.get_or_404(secretaire_id)
    if sec.role != 'secretaire' or sec.valide_par != current_user.id:
        return jsonify({'success': False, 'message': "Secrétaire non affiliée"}), 403
    sec.statut = 'valide'
    sec.date_validation = datetime.utcnow()
    db.session.commit()
    log_event('activer_secretaire', entite='user', entite_id=sec.id, details='Secrétaire activée par bourgmestre')
    return jsonify({'success': True, 'message': 'Secrétaire activée'})

@app.route('/api/bourgmestre/secretaires/<int:secretaire_id>/desactiver', methods=['POST'])
@login_required
def api_desactiver_secretaire(secretaire_id):
    if current_user.role != 'bourgmestre':
        return jsonify({'success': False, 'message': "Accès non autorisé"}), 403
    sec = User.query.get_or_404(secretaire_id)
    if sec.role != 'secretaire' or sec.valide_par != current_user.id:
        return jsonify({'success': False, 'message': "Secrétaire non affiliée"}), 403
    sec.statut = 'desactive'
    db.session.commit()
    log_event('desactiver_secretaire', entite='user', entite_id=sec.id, details='Secrétaire désactivée par bourgmestre')
    return jsonify({'success': True, 'message': 'Secrétaire désactivée'})

# --- Création d'une secrétaire par le bourgmestre ---
@app.route('/bourgmestre/creer_secretaire', methods=['GET', 'POST'])
@login_required
def creer_secretaire():
    if current_user.role != 'bourgmestre':
        flash('Accès non autorisé', 'error')
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        try:
            user = User(
                nom=request.form['nom_secretaire'],
                prenom=request.form['prenom_secretaire'],
                email=request.form['email_secretaire'],
                mot_de_passe=generate_password_hash(request.form['mot_de_passe_secretaire']),
                role='secretaire',
                statut='valide',
                valide_par=current_user.id,
                date_validation=datetime.utcnow()
            )
            db.session.add(user)
            db.session.commit()
            log_event('creer_secretaire', entite='user', entite_id=user.id, details='Secrétaire créée par bourgmestre')
            flash('Secrétaire créée et activée avec succès.', 'success')
            return redirect(url_for('lister_secretaires'))
        except Exception as e:
            db.session.rollback()
            flash('Erreur lors de la création de la secrétaire.', 'error')
            return redirect(url_for('creer_secretaire'))
    return render_template('creer_secretaire.html')

# --- Validation/Rejet bourgmestre (HTML) ---
@app.route('/admin/valider_bourgmestre/<int:candidature_id>')
@login_required
def valider_bourgmestre(candidature_id):
    if current_user.role != 'admin':
        flash('Accès non autorisé', 'error')
        return redirect(url_for('dashboard'))
    cand = BourgmestreCandidature.query.get_or_404(candidature_id)
    user = User.query.get_or_404(cand.user_id)
    commune = Commune.query.get_or_404(cand.commune_id)
    if commune.bourgmestre_id:
        cand.statut = 'rejete'
        db.session.commit()
        flash('Commune déjà attribuée. Candidature rejetée.', 'warning')
        return redirect(url_for('dashboard'))
    user.statut = 'valide'
    user.date_validation = datetime.utcnow()
    user.valide_par = current_user.id
    commune.bourgmestre_id = user.id
    commune.date_attribution = datetime.utcnow()
    cand.statut = 'valide'
    db.session.commit()
    flash('Bourgmestre validé et commune attribuée.', 'success')
    return redirect(url_for('dashboard'))

@app.route('/admin/rejeter_bourgmestre/<int:candidature_id>')
@login_required
def rejeter_bourgmestre(candidature_id):
    if current_user.role != 'admin':
        flash('Accès non autorisé', 'error')
        return redirect(url_for('dashboard'))
    cand = BourgmestreCandidature.query.get_or_404(candidature_id)
    cand.statut = 'rejete'
    db.session.commit()
    flash('Candidature de bourgmestre rejetée.', 'success')
    return redirect(url_for('dashboard'))

# Routes admin
@app.route('/admin/valider_hopital/<int:hopital_id>')
@login_required
def valider_hopital(hopital_id):
    if current_user.role != 'admin':
        flash('Accès non autorisé', 'error')
        return redirect(url_for('dashboard'))
    
    hopital = Hopital.query.get_or_404(hopital_id)
    hopital.statut = 'valide'
    hopital.date_validation = datetime.utcnow()
    hopital.valide_par = current_user.id
    
    # Valider aussi l'utilisateur hôpital
    user = User.query.filter_by(hopital_id=hopital.id, role='hopital').first()
    if user:
        user.statut = 'valide'
        user.date_validation = datetime.utcnow()
        user.valide_par = current_user.id
    
    db.session.commit()
    flash('Hôpital validé avec succès', 'success')
    return redirect(url_for('dashboard'))

@app.route('/admin/valider_particulier/<int:particulier_id>')
@login_required
def valider_particulier(particulier_id):
    if current_user.role != 'admin':
        flash('Accès non autorisé', 'error')
        return redirect(url_for('dashboard'))
    
    particulier = User.query.get_or_404(particulier_id)
    particulier.statut = 'valide'
    particulier.date_validation = datetime.utcnow()
    particulier.valide_par = current_user.id
    
    db.session.commit()
    flash('Particulier validé avec succès', 'success')
    return redirect(url_for('dashboard'))

@app.route('/admin/rejeter_hopital/<int:hopital_id>')
@login_required
def rejeter_hopital(hopital_id):
    if current_user.role != 'admin':
        flash('Accès non autorisé', 'error')
        return redirect(url_for('dashboard'))
    
    hopital = Hopital.query.get_or_404(hopital_id)
    hopital.statut = 'rejete'
    
    # Rejeter aussi l'utilisateur hôpital
    user = User.query.filter_by(hopital_id=hopital.id, role='hopital').first()
    if user:
        user.statut = 'rejete'
    
    db.session.commit()
    flash('Demande d\'hôpital rejetée', 'success')
    return redirect(url_for('dashboard'))

@app.route('/admin/rejeter_particulier/<int:particulier_id>')
@login_required
def rejeter_particulier(particulier_id):
    if current_user.role != 'admin':
        flash('Accès non autorisé', 'error')
        return redirect(url_for('dashboard'))
    
    particulier = User.query.get_or_404(particulier_id)
    particulier.statut = 'rejete'
    
    db.session.commit()
    flash('Demande de particulier rejetée', 'success')
    return redirect(url_for('dashboard'))

#############################################
#                API JSON                    #
#############################################

@app.route('/api/demandes/<int:demande_id>/verifier', methods=['POST'])
@login_required
def api_verifier_demande(demande_id):
    if current_user.role != 'secretaire':
        return jsonify({'success': False, 'message': "Accès non autorisé"}), 403
    demande = Demande.query.get_or_404(demande_id)
    if demande.status != 'en_attente':
        return jsonify({'success': False, 'message': "La demande n'est pas en attente."}), 400
    demande.status = 'verifiee'
    demande.id_secretaire = current_user.id
    db.session.commit()
    log_event('verifier_demande', entite='demande', entite_id=demande.id, details='Demande vérifiée')
    return jsonify({'success': True, 'message': 'Demande vérifiée et transmise au bourgmestre', 'demande': {
        'id': demande.id,
        'status': demande.status
    }})

@app.route('/api/demandes/<int:demande_id>/valider', methods=['POST'])
@login_required
def api_valider_demande(demande_id):
    if current_user.role != 'bourgmestre':
        return jsonify({'success': False, 'message': "Accès non autorisé"}), 403
    demande = Demande.query.get_or_404(demande_id)
    if demande.status != 'verifiee':
        return jsonify({'success': False, 'message': "La demande n'est pas vérifiée."}), 400
    demande.status = 'validee'
    demande.id_bourgmestre = current_user.id
    demande.date_validation = datetime.utcnow()
    acte = ActeNaissance(demande_id=demande.id)
    db.session.add(acte)
    db.session.commit()

    pdf_url = None
    try:
        pdf_abs_path = generate_acte_pdf(demande, acte, current_user)
        acte.pdf_path = pdf_abs_path
        db.session.commit()
        pdf_url = url_for('telecharger_acte_par_demande', demande_id=demande.id)
    except Exception as e:
        app.logger.exception('Erreur de génération du PDF: %s', e)

    log_event('valider_demande', entite='demande', entite_id=demande.id, details='Demande validée')
    return jsonify({'success': True, 'message': 'Demande validée et acte de naissance créé', 'demande': {
        'id': demande.id,
        'status': demande.status
    }, 'acte': {'id': acte.id, 'pdf_url': pdf_url}})

@app.route('/api/admin/hopitaux/<int:hopital_id>/valider', methods=['POST'])
@login_required
def api_valider_hopital(hopital_id):
    if current_user.role != 'admin':
        return jsonify({'success': False, 'message': "Accès non autorisé"}), 403
    hopital = Hopital.query.get_or_404(hopital_id)
    hopital.statut = 'valide'
    hopital.date_validation = datetime.utcnow()
    hopital.valide_par = current_user.id
    user = User.query.filter_by(hopital_id=hopital.id, role='hopital').first()
    if user:
        user.statut = 'valide'
        user.date_validation = datetime.utcnow()
        user.valide_par = current_user.id
    db.session.commit()
    log_event('valider_hopital', entite='hopital', entite_id=hopital.id, details='Hôpital validé par admin')
    return jsonify({'success': True, 'message': "Hôpital validé avec succès", 'hopital': {
        'id': hopital.id,
        'statut': hopital.statut
    }})

@app.route('/api/admin/hopitaux/<int:hopital_id>/rejeter', methods=['POST'])
@login_required
def api_rejeter_hopital(hopital_id):
    if current_user.role != 'admin':
        return jsonify({'success': False, 'message': "Accès non autorisé"}), 403
    hopital = Hopital.query.get_or_404(hopital_id)
    hopital.statut = 'rejete'
    user = User.query.filter_by(hopital_id=hopital.id, role='hopital').first()
    if user:
        user.statut = 'rejete'
    db.session.commit()
    log_event('rejeter_hopital', entite='hopital', entite_id=hopital.id, details='Hôpital rejeté par admin')
    return jsonify({'success': True, 'message': "Demande d'hôpital rejetée", 'hopital': {
        'id': hopital.id,
        'statut': hopital.statut
    }})

@app.route('/api/admin/particuliers/<int:particulier_id>/valider', methods=['POST'])
@login_required
def api_valider_particulier(particulier_id):
    if current_user.role != 'admin':
        return jsonify({'success': False, 'message': "Accès non autorisé"}), 403
    particulier = User.query.get_or_404(particulier_id)
    particulier.statut = 'valide'
    particulier.date_validation = datetime.utcnow()
    particulier.valide_par = current_user.id
    db.session.commit()
    log_event('valider_particulier', entite='user', entite_id=particulier.id, details='Particulier validé par admin')
    return jsonify({'success': True, 'message': "Particulier validé avec succès", 'particulier': {
        'id': particulier.id,
        'statut': particulier.statut
    }})

@app.route('/api/admin/particuliers/<int:particulier_id>/rejeter', methods=['POST'])
@login_required
def api_rejeter_particulier(particulier_id):
    if current_user.role != 'admin':
        return jsonify({'success': False, 'message': "Accès non autorisé"}), 403
    particulier = User.query.get_or_404(particulier_id)
    particulier.statut = 'rejete'
    db.session.commit()
    log_event('rejeter_particulier', entite='user', entite_id=particulier.id, details='Particulier rejeté par admin')
    return jsonify({'success': True, 'message': "Demande de particulier rejetée", 'particulier': {
        'id': particulier.id,
        'statut': particulier.statut
    }})

# Nouvelles API admin pour bourgmestres
@app.route('/api/admin/bourgmestres/<int:candidature_id>/valider', methods=['POST'])
@login_required
def api_valider_bourgmestre(candidature_id):
    if current_user.role != 'admin':
        return jsonify({'success': False, 'message': "Accès non autorisé"}), 403
    cand = BourgmestreCandidature.query.get_or_404(candidature_id)
    user = User.query.get_or_404(cand.user_id)
    commune = Commune.query.get_or_404(cand.commune_id)
    if commune.bourgmestre_id:
        cand.statut = 'rejete'
        db.session.commit()
        return jsonify({'success': False, 'message': 'Commune déjà attribuée. Candidature rejetée.'}), 400
    user.statut = 'valide'
    user.date_validation = datetime.utcnow()
    user.valide_par = current_user.id
    commune.bourgmestre_id = user.id
    commune.date_attribution = datetime.utcnow()
    cand.statut = 'valide'
    db.session.commit()
    log_event('valider_bourgmestre', entite='user', entite_id=user.id, details=f"Bourgmestre validé pour {commune.nom}")
    return jsonify({'success': True, 'message': 'Bourgmestre validé et commune attribuée', 'bourgmestre': {
        'id': user.id,
        'commune_id': commune.id
    }})

@app.route('/api/admin/bourgmestres/<int:candidature_id>/rejeter', methods=['POST'])
@login_required
def api_rejeter_bourgmestre(candidature_id):
    if current_user.role != 'admin':
        return jsonify({'success': False, 'message': "Accès non autorisé"}), 403
    cand = BourgmestreCandidature.query.get_or_404(candidature_id)
    cand.statut = 'rejete'
    db.session.commit()
    log_event('rejeter_bourgmestre', entite='candidature', entite_id=cand.id, details='Candidature bourgmestre rejetée')
    return jsonify({'success': True, 'message': 'Candidature de bourgmestre rejetée'})

# Téléchargement sécurisé de l'acte par demande
@app.route('/actes/demande/<int:demande_id>/telecharger')
@login_required
def telecharger_acte_par_demande(demande_id: int):
    demande = Demande.query.get_or_404(demande_id)

    # Contrôle d'accès
    if current_user.role not in ['admin', 'secretaire', 'bourgmestre']:
        if current_user.role == 'hopital':
            if demande.id_hopital != current_user.hopital_id:
                flash('Accès non autorisé', 'error')
                return redirect(url_for('dashboard'))
        elif current_user.role == 'particulier':
            if demande.id_particulier != current_user.id:
                flash('Accès non autorisé', 'error')
                return redirect(url_for('dashboard'))
        else:
            flash('Accès non autorisé', 'error')
            return redirect(url_for('dashboard'))

    acte = ActeNaissance.query.filter_by(demande_id=demande.id).first()
    if not acte:
        flash("Aucun acte associé à cette demande", 'error')
        return redirect(url_for('dashboard'))

    # Générer à la volée si manquant
    if not acte.pdf_path or not os.path.exists(acte.pdf_path):
        try:
            bourgmestre_user = User.query.get(demande.id_bourgmestre)
            if not bourgmestre_user:
                flash("Acte non signé: bourgmestre introuvable", 'error')
                return redirect(url_for('dashboard'))
            pdf_abs_path = generate_acte_pdf(demande, acte, bourgmestre_user)
            acte.pdf_path = pdf_abs_path
            db.session.commit()
        except Exception as e:
            app.logger.exception('Erreur de génération du PDF: %s', e)
            flash("Erreur lors de la génération du PDF", 'error')
            return redirect(url_for('dashboard'))

    return send_file(acte.pdf_path, as_attachment=True, download_name=f"acte_naissance_{acte.id}.pdf")

# Tableau de bord et encart historique
@app.route('/dashboard')
@login_required
def dashboard():
    recent_logs = []
    if current_user.role == 'admin':
        recent_logs = Historique.query.order_by(Historique.date_evenement.desc()).limit(10).all()
    else:
        recent_logs = Historique.query.filter_by(user_id=current_user.id).order_by(Historique.date_evenement.desc()).limit(10).all()

    if current_user.role == 'admin':
        hopitaux_en_attente = Hopital.query.filter_by(statut='en_attente_validation').all()
        particuliers_en_attente = User.query.filter_by(role='particulier', statut='en_attente_validation').all()
        bourgmestres_en_attente = BourgmestreCandidature.query.filter_by(statut='en_attente').all()
        return render_template('admin_dashboard.html', 
                             hopitaux_en_attente=hopitaux_en_attente,
                             particuliers_en_attente=particuliers_en_attente,
                             bourgmestres_en_attente=bourgmestres_en_attente,
                             User=User,
                             Commune=Commune,
                             recent_logs=recent_logs)
    elif current_user.role in ['hopital', 'particulier']:
        if current_user.role == 'hopital':
            demandes = Demande.query.filter_by(id_hopital=current_user.hopital_id).all()
        else:
            demandes = Demande.query.filter_by(id_particulier=current_user.id).all()
        return render_template('dashboard.html', demandes=demandes, user=current_user, recent_logs=recent_logs)
    elif current_user.role in ['secretaire', 'bourgmestre']:
        if current_user.role == 'secretaire':
            demandes = Demande.query.filter_by(status='en_attente').all()
        else:
            demandes = Demande.query.filter_by(status='verifiee').all()
        return render_template('dashboard.html', demandes=demandes, user=current_user, recent_logs=recent_logs)
    return redirect(url_for('index'))

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        
        # Seed des 24 communes de Kinshasa si absent
        if not Commune.query.first():
            communes_kin = [
                'Barumbu', 'Bandalungwa', 'Binza-Ozone', 'Bumbu', 'Gombe', 'Kalam', 'Kalamu', 'Kasa-Vubu',
                'Kintambo', 'Kinshasa', 'Kisenso', 'Lemba', 'Limeté', 'Lingwala', 'Makala', 'Maluku',
                'Masina', 'Matete', 'Mont Ngafula', 'Ndjili', 'Ngaba', 'Ngaliema', 'Nsele', 'Selembao'
            ]
            for nom in communes_kin:
                try:
                    db.session.add(Commune(nom=nom))
                except Exception:
                    db.session.rollback()
            db.session.commit()
        
        # Créer des utilisateurs de test si la base est vide
        if not User.query.first():
            admin = User(
                nom='Administrateur',
                prenom='Admin',
                email='admin@acte.com',
                mot_de_passe=generate_password_hash('adminacte123'),
                role='admin',
                statut='valide'
            )
            db.session.add(admin)
            users_test = [
                User(nom='Martin', prenom='Marie', email='marie.martin@commune.be', 
                     mot_de_passe=generate_password_hash('password123'), role='secretaire', statut='valide', valide_par=1),
                User(nom='Bernard', prenom='Pierre', email='pierre.bernard@commune.be', 
                     mot_de_passe=generate_password_hash('password123'), role='bourgmestre', statut='valide')
            ]
            for user in users_test:
                db.session.add(user)
            db.session.commit()
    
    app.run(debug=True) 