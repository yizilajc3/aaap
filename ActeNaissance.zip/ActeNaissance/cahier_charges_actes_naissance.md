Cahier des charges pour le projet "Gestion des actes de naissance"

1. Objectif général
Mettre en place une application web permettant la gestion complète des demandes d’actes de naissance, depuis la soumission par les hôpitaux jusqu’à la validation par le bourgmestre et l’enregistrement officiel.

2. Objectifs spécifiques
- Faciliter la soumission et le suivi des demandes d’actes de naissance.
- Assurer la validation sécurisée par le bourgmestre.
- Générer automatiquement l’acte de naissance officiel (format PDF).
- Enregistrer les actes validés dans un registre électronique fiable.
- Envoyer des notifications sur le statut des demandes.

3. Technologies choisies
- Backend : Python + Flask
- Base de données : SQLite
- Frontend : HTML5, CSS3, Bootstrap (optionnel)
- PDF : library `reportlab` ou `WeasyPrint`
- Authentification : Flask-Login ou JWT
- Gestion des rôles : Hôpital, Secrétaire, Bourgmestre

4. Fonctionnalités principales
- Gestion des utilisateurs : création, authentification et rôles.
- Gestion des demandes : soumission par hôpitaux, vérification par secrétaire, validation par bourgmestre.
- Génération et enregistrement des actes : PDF et base de données.
- Suivi et notifications : statut des demandes.
- Administration : gestion des utilisateurs et statistiques.

5. Base de données (SQLite)
- `users` : id, nom, prénom, email, mot_de_passe, role
- `demands` : id, id_hopital, id_secretaire, id_bourgmestre, status, date_creation, date_validation
- `birth_records` : id, demand_id, nom_enfant, prenom_enfant, date_naissance, nom_parent, prenom_parent, pdf_path

6. Étapes de réalisation
Phase 1 : Préparation
- Installer Python, Flask et SQLite.
- Créer l’architecture du projet Flask.
- Configurer la base de données.

Phase 2 : Gestion des utilisateurs
- Implémenter inscription et connexion.
- Créer le système de rôles et permissions.

Phase 3 : Soumission et gestion des demandes
- Hôpital : formulaire de demande.
- Secrétaire : tableau de bord de vérification et transmission.
- Bourgmestre : interface de validation ou rejet.

Phase 4 : Génération et enregistrement des actes
- Générer le PDF après validation.
- Stocker le PDF et informations dans SQLite.

Phase 5 : Suivi et notifications
- Mettre en place le suivi des statuts.
- Ajouter notifications pour les utilisateurs.

Phase 6 : Tests et déploiement
- Tester toutes les fonctionnalités.
- Corriger les bugs et sécuriser les accès.
- Déploiement local ou serveur léger.

7. Livrables
- Application Flask fonctionnelle.
- Base de données SQLite.
- PDF des actes validés.
- Documentation utilisateur et technique.

