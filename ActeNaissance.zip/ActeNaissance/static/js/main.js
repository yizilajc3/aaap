// Fichier JavaScript principal pour l'application de gestion des actes de naissance

document.addEventListener('DOMContentLoaded', function() {
    console.log('Application de gestion des actes de naissance chargée');
    
    // Initialisation des animations
    initializeAnimations();
    
    // Initialisation des interactions
    initializeInteractions();
    
    // Initialisation des tooltips Bootstrap
    initializeTooltips();
    
    // Initialisation des animations de scroll
    initializeScrollAnimations();
});

/**
 * Initialise les animations CSS avec des délais
 */
function initializeAnimations() {
    // Animation des éléments avec délai
    const animatedElements = document.querySelectorAll('[data-delay]');
    animatedElements.forEach(element => {
        const delay = parseFloat(element.getAttribute('data-delay'));
        element.style.animationDelay = `${delay}s`;
    });
    
    // Animation des cartes de statistiques
    const statCards = document.querySelectorAll('.stat-card');
    statCards.forEach((card, index) => {
        card.style.animationDelay = `${index * 0.1}s`;
    });
    
    // Animation des étapes du processus
    const processSteps = document.querySelectorAll('.process-step');
    processSteps.forEach((step, index) => {
        step.style.animationDelay = `${index * 0.2}s`;
    });
}

/**
 * Initialise les interactions utilisateur
 */
function initializeInteractions() {
    // Effet de survol sur les cartes
    const cards = document.querySelectorAll('.card, .feature-card, .stat-card');
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
    
    // Effet de focus sur les formulaires
    const formInputs = document.querySelectorAll('.form-control');
    formInputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.parentElement.classList.add('focused');
        });
        
        input.addEventListener('blur', function() {
            this.parentElement.classList.remove('focused');
        });
    });
    
    // Animation des boutons
    const buttons = document.querySelectorAll('.btn');
    buttons.forEach(button => {
        button.addEventListener('click', function(e) {
            // Créer un effet de ripple
            createRippleEffect(e, this);
        });
    });
}

/**
 * Initialise les tooltips Bootstrap
 */
function initializeTooltips() {
    // Vérifier si Bootstrap est disponible
    if (typeof bootstrap !== 'undefined') {
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }
}

/**
 * Initialise les animations au scroll
 */
function initializeScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate__animated', 'animate__fadeInUp');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);
    
    // Observer les éléments qui doivent être animés au scroll
    const scrollElements = document.querySelectorAll('.feature-card, .process-step, .stat-card');
    scrollElements.forEach(el => {
        observer.observe(el);
    });
}

/**
 * Crée un effet de ripple sur les boutons
 */
function createRippleEffect(event, button) {
    const ripple = document.createElement('span');
    const rect = button.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = event.clientX - rect.left - size / 2;
    const y = event.clientY - rect.top - size / 2;
    
    ripple.style.width = ripple.style.height = size + 'px';
    ripple.style.left = x + 'px';
    ripple.style.top = y + 'px';
    ripple.classList.add('ripple');
    
    button.appendChild(ripple);
    
    setTimeout(() => {
        ripple.remove();
    }, 600);
}

/**
 * Animation de compteur pour les statistiques
 */
function animateCounter(element, target, duration = 2000) {
    let start = 0;
    const increment = target / (duration / 16);
    
    function updateCounter() {
        start += increment;
        if (start < target) {
            element.textContent = Math.floor(start);
            requestAnimationFrame(updateCounter);
        } else {
            element.textContent = target;
        }
    }
    
    updateCounter();
}

/**
 * Gestion des messages flash avec animation
 */
function showFlashMessage(message, type = 'info') {
    const alertContainer = document.createElement('div');
    alertContainer.className = `alert alert-${type} alert-dismissible fade show animate__animated animate__fadeInDown`;
    alertContainer.innerHTML = `
        <i class="fas fa-${getIconForType(type)} me-2"></i>
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    // Insérer au début du contenu principal
    const mainContent = document.querySelector('.main-content');
    if (mainContent) {
        mainContent.insertBefore(alertContainer, mainContent.firstChild);
    }
    
    // Auto-suppression après 5 secondes
    setTimeout(() => {
        if (alertContainer.parentNode) {
            alertContainer.classList.add('animate__fadeOutUp');
            setTimeout(() => {
                if (alertContainer.parentNode) {
                    alertContainer.remove();
                }
            }, 500);
        }
    }, 5000);
}

/**
 * Retourne l'icône appropriée selon le type de message
 */
function getIconForType(type) {
    const icons = {
        'success': 'check-circle',
        'error': 'exclamation-triangle',
        'warning': 'exclamation-triangle',
        'info': 'info-circle'
    };
    return icons[type] || 'info-circle';
}

/**
 * Animation de chargement
 */
function showLoading(element) {
    element.innerHTML = `
        <div class="text-center">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Chargement...</span>
            </div>
        </div>
    `;
}

/**
 * Masquer l'animation de chargement
 */
function hideLoading(element, content) {
    element.innerHTML = content;
}

/**
 * Validation des formulaires en temps réel
 */
function initializeFormValidation() {
    const forms = document.querySelectorAll('.needs-validation');
    forms.forEach(form => {
        const inputs = form.querySelectorAll('input, select, textarea');
        
        inputs.forEach(input => {
            input.addEventListener('input', function() {
                validateField(this);
            });
            
            input.addEventListener('blur', function() {
                validateField(this);
            });
        });
        
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
                
                // Valider tous les champs
                inputs.forEach(input => validateField(input));
            }
            form.classList.add('was-validated');
        });
    });
}

/**
 * Valide un champ individuel
 */
function validateField(field) {
    const isValid = field.checkValidity();
    const feedback = field.parentNode.querySelector('.invalid-feedback');
    
    if (isValid) {
        field.classList.remove('is-invalid');
        field.classList.add('is-valid');
        if (feedback) feedback.style.display = 'none';
    } else {
        field.classList.remove('is-valid');
        field.classList.add('is-invalid');
        if (feedback) feedback.style.display = 'block';
    }
}

/**
 * Gestion des tableaux avec tri et recherche
 */
function initializeTableFeatures() {
    const tables = document.querySelectorAll('.table');
    tables.forEach(table => {
        // Ajouter la fonctionnalité de tri
        const headers = table.querySelectorAll('th[data-sortable]');
        headers.forEach(header => {
            header.addEventListener('click', function() {
                sortTable(table, this);
            });
        });
    });
}

/**
 * Trie un tableau selon la colonne cliquée
 */
function sortTable(table, header) {
    const column = Array.from(header.parentNode.children).indexOf(header);
    const tbody = table.querySelector('tbody');
    const rows = Array.from(tbody.querySelectorAll('tr'));
    
    const isAscending = header.classList.contains('sort-asc');
    
    rows.sort((a, b) => {
        const aValue = a.children[column].textContent.trim();
        const bValue = b.children[column].textContent.trim();
        
        if (isAscending) {
            return bValue.localeCompare(aValue);
        } else {
            return aValue.localeCompare(bValue);
        }
    });
    
    // Réorganiser les lignes
    rows.forEach(row => tbody.appendChild(row));
    
    // Mettre à jour l'indicateur de tri
    headers.forEach(h => h.classList.remove('sort-asc', 'sort-desc'));
    header.classList.add(isAscending ? 'sort-desc' : 'sort-asc');
}

/**
 * Animation de la barre de progression
 */
function animateProgressBar(progressBar, targetValue, duration = 1000) {
    const startValue = 0;
    const startTime = performance.now();
    
    function updateProgress(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        const currentValue = startValue + (targetValue - startValue) * progress;
        progressBar.style.width = currentValue + '%';
        progressBar.setAttribute('aria-valuenow', currentValue);
        
        if (progress < 1) {
            requestAnimationFrame(updateProgress);
        }
    }
    
    requestAnimationFrame(updateProgress);
}

/**
 * Gestion du mode sombre/clair
 */
function initializeThemeToggle() {
    const themeToggle = document.querySelector('#theme-toggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            document.body.classList.toggle('dark-theme');
            const isDark = document.body.classList.contains('dark-theme');
            localStorage.setItem('theme', isDark ? 'dark' : 'light');
            
            // Mettre à jour l'icône
            const icon = this.querySelector('i');
            icon.className = isDark ? 'fas fa-sun' : 'fas fa-moon';
        });
        
        // Restaurer le thème sauvegardé
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme === 'dark') {
            document.body.classList.add('dark-theme');
            const icon = themeToggle.querySelector('i');
            icon.className = 'fas fa-sun';
        }
    }
}

/**
 * Gestion des notifications toast
 */
function showToast(message, type = 'info', duration = 3000) {
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white bg-${type} border-0`;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    toast.setAttribute('aria-atomic', 'true');
    
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                <i class="fas fa-${getIconForType(type)} me-2"></i>
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;
    
    // Créer le conteneur de toast s'il n'existe pas
    let toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.className = 'toast-container position-fixed top-0 end-0 p-3';
        toastContainer.style.zIndex = '9999';
        document.body.appendChild(toastContainer);
    }
    
    toastContainer.appendChild(toast);
    
    // Afficher le toast
    if (typeof bootstrap !== 'undefined') {
        const bsToast = new bootstrap.Toast(toast);
        bsToast.show();
    }
    
    // Auto-suppression
    setTimeout(() => {
        if (toast.parentNode) {
            toast.remove();
        }
    }, duration);
}

// Initialisation des fonctionnalités avancées
document.addEventListener('DOMContentLoaded', function() {
    initializeFormValidation();
    initializeTableFeatures();
    initializeThemeToggle();
    
    // Animation des compteurs de statistiques
    const statNumbers = document.querySelectorAll('.stat-number');
    statNumbers.forEach(stat => {
        const target = parseInt(stat.textContent);
        if (!isNaN(target)) {
            stat.textContent = '0';
            setTimeout(() => {
                animateCounter(stat, target);
            }, 1000);
        }
    });
});

// Export des fonctions pour utilisation globale
window.AppUtils = {
    showFlashMessage,
    showToast,
    showLoading,
    hideLoading,
    animateProgressBar
};

// --- AJAX actions & button state management ---
// Ajout: loading sur submit des formulaires
document.addEventListener('DOMContentLoaded', function() {
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const submitBtn = form.querySelector('button[type="submit"], .btn[type="submit"]');
            if (submitBtn) {
                submitBtn.setAttribute('disabled', 'disabled');
                const label = submitBtn.innerHTML;
                submitBtn.dataset.originalLabel = label;
                submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>Chargement...';
            }
        });
    });
});

// Compléter les handlers d'actions
document.addEventListener('DOMContentLoaded', function() {
    const actionHandlers = {
        verifier_demande: (id) => `/api/demandes/${id}/verifier`,
        valider_demande: (id) => `/api/demandes/${id}/valider`,
        valider_hopital: (id) => `/api/admin/hopitaux/${id}/valider`,
        rejeter_hopital: (id) => `/api/admin/hopitaux/${id}/rejeter`,
        valider_particulier: (id) => `/api/admin/particuliers/${id}/valider`,
        rejeter_particulier: (id) => `/api/admin/particuliers/${id}/rejeter`,
        valider_bourgmestre: (id) => `/api/admin/bourgmestres/${id}/valider`,
        rejeter_bourgmestre: (id) => `/api/admin/bourgmestres/${id}/rejeter`,
        activer_secretaire: (id) => `/api/bourgmestre/secretaires/${id}/activer`,
        desactiver_secretaire: (id) => `/api/bourgmestre/secretaires/${id}/desactiver`
    };

    document.body.addEventListener('click', async function(e) {
        const btn = e.target.closest('.js-action');
        if (!btn) return;
        e.preventDefault();
        const action = btn.getAttribute('data-action');
        const id = btn.getAttribute('data-id');
        if (!action || !id || !actionHandlers[action]) return;

        setButtonLoading(btn, true);
        try {
            const res = await fetch(actionHandlers[action](id), { method: 'POST', headers: { 'X-Requested-With': 'XMLHttpRequest' } });
            const data = await res.json().catch(() => ({}));
            if (!res.ok || !data.success) {
                const msg = (data && data.message) ? data.message : 'Une erreur est survenue';
                AppUtils.showToast(msg, 'danger');
                return;
            }
            AppUtils.showToast(data.message || 'Action effectuée', 'success');
            applyDomUpdatesAfterAction(action, id, data);
        } catch (err) {
            console.error(err);
            AppUtils.showToast('Erreur réseau', 'danger');
        } finally {
            setButtonLoading(btn, false);
        }
    });
});

function setButtonLoading(button, isLoading) {
    const label = button.querySelector('.btn-label');
    const spinner = button.querySelector('.btn-spinner');
    if (isLoading) {
        button.setAttribute('disabled', 'disabled');
        if (label) label.classList.add('opacity-0');
        if (spinner) spinner.classList.remove('d-none');
    } else {
        button.removeAttribute('disabled');
        if (label) label.classList.remove('opacity-0');
        if (spinner) spinner.classList.add('d-none');
    }
}

function applyDomUpdatesAfterAction(action, id, data) {
    const userRole = document.body.getAttribute('data-user-role');
    if (action === 'verifier_demande') {
        updateDemandeRowStatus(id, 'verifiee');
        updateCountersDelta({ attente: -1, verifiee: +1 });
    } else if (action === 'valider_demande') {
        updateDemandeRowStatus(id, 'validee', data);
        updateCountersDelta({ verifiee: -1, validee: +1 });
    } else if (action === 'valider_hopital' || action === 'rejeter_hopital') {
        removeRowById(`hopital-row-${id}`);
        updateAdminCountersDelta({ hopitaux: -1 });
    } else if (action === 'valider_particulier' || action === 'rejeter_particulier') {
        removeRowById(`particulier-row-${id}`);
        updateAdminCountersDelta({ particuliers: -1 });
    } else if (action === 'valider_bourgmestre' || action === 'rejeter_bourgmestre') {
        removeRowById(`bourgmestre-row-${id}`);
    } else if (action === 'activer_secretaire' || action === 'desactiver_secretaire') {
        toggleSecretaireRow(id, action === 'activer_secretaire');
    }
}

function updateDemandeRowStatus(id, newStatus, data) {
    const row = document.getElementById(`demande-row-${id}`);
    if (!row) return;
    row.setAttribute('data-status', newStatus);

    const statusCell = row.querySelector('.status-cell');
    if (statusCell) {
        if (newStatus === 'verifiee') {
            statusCell.innerHTML = '<span class="badge bg-info"><i class="fas fa-check me-1"></i>Vérifiée</span>';
        } else if (newStatus === 'validee') {
            statusCell.innerHTML = '<span class="badge bg-success"><i class="fas fa-stamp me-1"></i>Validée</span>';
        }
    }

    const actionsCell = row.querySelector('.actions-cell');
    if (actionsCell) {
        if (newStatus === 'verifiee') {
            actionsCell.innerHTML = `<button class="btn btn-warning btn-sm js-action" data-action="valider_demande" data-id="${id}">
                <span class="btn-label"><i class="fas fa-stamp me-1"></i>Valider</span>
                <span class="btn-spinner spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
            </button>`;
        } else if (newStatus === 'validee') {
            const pdfUrl = data && data.acte && data.acte.pdf_url ? data.acte.pdf_url : `/actes/demande/${id}/telecharger`;
            actionsCell.innerHTML = `<a href="${pdfUrl}" class="btn btn-outline-danger btn-sm">
                <i class="fas fa-file-pdf me-1"></i>Télécharger
            </a>`;
        }
    }
}

function updateCountersDelta(delta) {
    const totalEl = document.getElementById('count-total');
    const attEl = document.getElementById('count-attente');
    const verEl = document.getElementById('count-verifiee');
    const valEl = document.getElementById('count-validee');
    if (totalEl) {
        const newTotal = (parseInt(totalEl.textContent) || 0) + ((delta.total || 0));
        if (!isNaN(newTotal)) totalEl.textContent = String(newTotal);
    }
    if (attEl && delta.attente) attEl.textContent = String((parseInt(attEl.textContent) || 0) + delta.attente);
    if (verEl && delta.verifiee) verEl.textContent = String((parseInt(verEl.textContent) || 0) + delta.verifiee);
    if (valEl && delta.validee) valEl.textContent = String((parseInt(valEl.textContent) || 0) + delta.validee);
}

function updateAdminCountersDelta(delta) {
    const hEl = document.getElementById('count-hopitaux');
    const pEl = document.getElementById('count-particuliers');
    const tEl = document.getElementById('count-total-pending');
    if (hEl && delta.hopitaux) hEl.textContent = String((parseInt(hEl.textContent) || 0) + delta.hopitaux);
    if (pEl && delta.particuliers) pEl.textContent = String((parseInt(pEl.textContent) || 0) + delta.particuliers);
    if (tEl) {
        const totalDelta = (delta.hopitaux || 0) + (delta.particuliers || 0);
        tEl.textContent = String((parseInt(tEl.textContent) || 0) + totalDelta);
    }
}

function removeRowById(rowId) {
    const row = document.getElementById(rowId);
    if (!row) return;
    row.classList.add('animate__animated', 'animate__fadeOut');
    setTimeout(() => row.remove(), 300);
} 

function toggleSecretaireRow(id, isActive) {
    const row = document.getElementById(`secretaire-row-${id}`);
    if (!row) return;
    row.setAttribute('data-status', isActive ? 'valide' : 'desactive');
    const statutCell = row.querySelector('.statut-cell');
    if (statutCell) {
        if (isActive) {
            statutCell.innerHTML = '<span class="badge bg-success">Actif</span>';
        } else {
            statutCell.innerHTML = '<span class="badge bg-secondary">Désactivé</span>';
        }
    }
    const actionsCell = row.querySelector('.actions-cell');
    if (actionsCell) {
        if (isActive) {
            actionsCell.innerHTML = `<button class="btn btn-outline-secondary btn-sm js-action" data-action="desactiver_secretaire" data-id="${id}">
                <span class="btn-label"><i class="fas fa-user-slash me-1"></i>Désactiver</span>
                <span class="btn-spinner spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
            </button>`;
        } else {
            actionsCell.innerHTML = `<button class="btn btn-outline-success btn-sm js-action" data-action="activer_secretaire" data-id="${id}">
                <span class="btn-label"><i class="fas fa-user-check me-1"></i>Activer</span>
                <span class="btn-spinner spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
            </button>`;
        }
    }
} 